(function() {
  app.LoginController = function($scope) {};

}).call(this);
